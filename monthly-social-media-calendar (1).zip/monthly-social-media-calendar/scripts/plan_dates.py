#!/usr/bin/env python3
"""Pick posting dates for a social media calendar month.

Usage:
  python3 plan_dates.py YEAR MONTH [--working Mon-Fri] [--preferred Tue,Thu,Fri]
                        [--min 10] [--max 12] [--holidays 2026-12-25,2026-12-31]
                        [--fixed 2026-11-14] [--json]

--working    Days that may carry posts. Ranges (Mon-Fri) and lists (Mon,Wed,Sat) both work.
--preferred  Days to favour when there are more working days than posts.
--min/--max  Post count range. Scaled by working days: 22+ -> max, 20-21 -> midpoint, fewer -> min.
--holidays   Dates never to post on (comma-separated ISO dates).
--fixed      Dates that must carry a post (special days). Each replaces the nearest planned slot.
             A fixed date on a non-working day or holiday is moved to the nearest working day
             and reported as a warning.
--json       Print JSON instead of a table.

Only the Python standard library is used.
"""
import argparse
import calendar
import datetime as dt
import json
import sys

DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


def parse_days(text):
    out = set()
    for part in text.replace(" ", "").lower().split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            i, j = DAYS.index(a[:3]), DAYS.index(b[:3])
            k = i
            while True:
                out.add(k)
                if k == j:
                    break
                k = (k + 1) % 7
        else:
            out.add(DAYS.index(part[:3]))
    return out


def label(d):
    return f"{d.strftime('%b')} {d.day} ({d.strftime('%a')})"


def parse_dates(text):
    if not text:
        return []
    return [dt.date.fromisoformat(s.strip()) for s in text.split(",") if s.strip()]


def plan(year, month, working, preferred, lo, hi, holidays=(), fixed=()):
    holidays = set(holidays)
    last = calendar.monthrange(year, month)[1]
    days = [dt.date(year, month, d) for d in range(1, last + 1)]
    days = [d for d in days if d.weekday() in working and d not in holidays]
    warnings = []
    if not days:
        return [], ["No working days in this month with the given settings."]

    n = hi if len(days) >= 22 else (lo + hi) // 2 if len(days) >= 20 else lo
    n = max(1, min(n, len(days)))

    pref = [d for d in days if d.weekday() in preferred]
    pool = pref if len(pref) >= n else days
    idx = sorted({round(i * (len(pool) - 1) / max(n - 1, 1)) for i in range(n)})
    chosen = [pool[i] for i in idx]
    # Top up if rounding collapsed any slots.
    for d in days:
        if len(chosen) >= n:
            break
        if d not in chosen:
            chosen.append(d)
    chosen = sorted(chosen)

    for f in fixed:
        target = f
        if f.year != year or f.month != month:
            warnings.append(f"{f} is outside {year}-{month:02d}; ignored.")
            continue
        if f not in days:
            target = min(days, key=lambda d: (abs((d - f).days), d))
            warnings.append(f"{f} is not a working day; moved to {target}.")
        if target in chosen:
            continue
        free = [c for c in chosen if c not in fixed]
        if not free:
            warnings.append(f"No slot left to swap for {target}.")
            continue
        drop = min(free, key=lambda d: (abs((d - target).days), d))
        chosen.remove(drop)
        chosen.append(target)
        chosen.sort()

    return chosen, warnings


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("year", type=int)
    p.add_argument("month", type=int)
    p.add_argument("--working", default="Mon-Fri")
    p.add_argument("--preferred", default="Tue,Thu,Fri")
    p.add_argument("--min", dest="lo", type=int, default=10)
    p.add_argument("--max", dest="hi", type=int, default=12)
    p.add_argument("--holidays", default="")
    p.add_argument("--fixed", default="")
    p.add_argument("--json", action="store_true")
    a = p.parse_args(argv)

    if a.lo > a.hi:
        p.error("--min cannot be larger than --max")

    dates, warnings = plan(
        a.year, a.month, parse_days(a.working), parse_days(a.preferred),
        a.lo, a.hi, parse_dates(a.holidays), parse_dates(a.fixed),
    )

    if a.json:
        print(json.dumps({
            "dates": [d.isoformat() for d in dates],
            "labels": [label(d) for d in dates],
            "count": len(dates),
            "warnings": warnings,
        }, indent=2))
    else:
        for i, d in enumerate(dates, 1):
            print(f"{i:>2}. {d.isoformat()}  {label(d)}")
        print(f"Total: {len(dates)} posts")
        for w in warnings:
            print(f"Warning: {w}", file=sys.stderr)


if __name__ == "__main__":
    main()
